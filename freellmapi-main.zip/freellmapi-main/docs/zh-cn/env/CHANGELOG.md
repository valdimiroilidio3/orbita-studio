[English](../../en/env/CHANGELOG.md) · **简体中文**

# 变更记录

`docs/env/` 的修订历史，列出塑造了本文档所述运行时配置面的提交。最新在前。

| Commit | Date | Summary |
| --- | --- | --- |
| `473d790` | 2026-08-20 | fix(modelscope): stop health checks burning magic-grain quota (#882) — basis for the `MODELSCOPE_VALIDATE_CACHE_MS` entry. |
| `48591a8` | 2026-08-12 | fix(router): warn when MODEL_ROUTING_OVERRIDES never apply (#857) — boot-log warning for unmatched model ids. |
| `8f27336` | 2026-08-12 | feat(vision): end-to-end image input, body limits, inbound normalization (#852) — introduced `REQUEST_BODY_LIMIT_MB` and the `IMAGE_NORMALIZE*` knobs. |
| `c3f538e` | 2026-08-11 | feat(routing): per-model weight overrides via MODEL_ROUTING_OVERRIDES (#747) — introduced the routing override variable. |
| `ba39318` | 2026-08-11 | feat(dashboard): automatic update check w/ release-notes dialog (#782) — automatic release reminder behind the update-checker settings. |
| `8cb75ac` | 2026-08-10 | feat(proxy): opt-in X-Fallback-Detail header (#792) — introduced `FALLBACK_DETAIL_HEADER`. |
| `a6f7718` | 2026-08-06 | fix(db): harden data dir so WAL sidecars are covered (#795) — data-directory restriction and `FREEAPI_DB_DIR_HARDENING`. |
| `29eb340` | 2026-08-06 | feat: in-dashboard update checker (#635) — `FREELLMAPI_UPDATE_CHECK` and related variables. |

Regenerate with `git log --oneline -- .env.example`.
