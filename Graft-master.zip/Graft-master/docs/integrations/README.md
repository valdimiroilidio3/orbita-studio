# Integrations

Graft is "just a binary" by design — anything that can spawn a subprocess can use it. The `integrations/` directory ships the glue for the major AI development surfaces, so you do not have to write that glue yourself.

```
┌─────────────────────────────┐    ┌─────────────────────────────┐
│ LLM chat clients            │    │ Coding agents (CLI-based)   │
│ Claude Desktop · ChatGPT    │    │ Claude Code · Codex · ...   │
└──────────────┬──────────────┘    └──────────────┬──────────────┘
               │ MCP (stdio or HTTP)              │ subprocess
               ▼                                  ▼
┌─────────────────────────────┐    ┌─────────────────────────────┐
│ integrations/mcp-server/    │    │ graft CLI                   │
│  · server.py  (stdio)       │───▶│  → unix socket              │
│  · oauth_gateway.py (HTTP)  │    │                             │
└─────────────────────────────┘    └──────────────┬──────────────┘
                                                  ▼
                                     ┌─────────────────────────────┐
                                     │ graftd (daemon)             │
                                     │  SQLite + sqlite-vec + FTS5 │
                                     │  + BGE-M3 (llama.cpp)       │
                                     └─────────────────────────────┘
```

Two families:

| Family | Mechanism | Where it lives |
| ------ | --------- | -------------- |
| **CLI assistants** (Claude Code, Codex, Open Code, Gemini CLI) | The harness already spawns subprocesses. We ship skills that instruct the model when to call `graft`; `graft setup` installs them, and `/graft-init` writes the usage rule into the instruction file the agent already reads. | `integrations/claude-code/`, `integrations/codex/`, `integrations/opencode/`, `integrations/gemini-cli/` |
| **Chat clients** (Claude Desktop, ChatGPT) | No subprocess in the client. We expose graft as an **MCP server** (the [Model Context Protocol](https://modelcontextprotocol.io)). | `integrations/claude-ai/`, `integrations/chatgpt/`, both backed by `integrations/mcp-server/` |

## Matrix

| Agent          | Integration type             | Where it lives                                       |
| -------------- | ---------------------------- | ---------------------------------------------------- |
| Claude Code    | Skills + rule + plugin hooks | `integrations/claude-code/`                          |
| Codex          | Skills + `AGENTS.md` rule    | `integrations/codex/`                                |
| Claude Desktop | MCP server (stdio)           | `integrations/claude-ai/` + `integrations/mcp-server/` |
| ChatGPT        | MCP server (stdio or HTTP)   | `integrations/chatgpt/` + `integrations/mcp-server/` |
| Gemini CLI     | `GEMINI.md` memory file      | `integrations/gemini-cli/`                           |
| Open Code      | Skills; optional `AGENTS.md` | `integrations/opencode/`                             |

Each adapter has its own README with install steps.

---

## Two complementary layers

For the CLI assistants we ship **two** things that look similar but behave very differently:

### Skills (or `AGENTS.md`, or `GEMINI.md`)

These are **prompts**. They tell the model **when** to use graft. The rule `/graft-init`
writes is a zero-touch lifecycle: once set up, the user never has to run a graft command.

- once per session in a project, `graft status` (one cheap call, never starts the
  daemon) and the bounded housekeeping its `next` list asks for: a `/learn bootstrap`
  pass on a project seen for the first time (task area first, never blocking the
  user's task), `apply-safe`, a small batch of maintenance candidates;
- search before non-trivial work;
- repair a note contradicted by the code on the spot (`graft maintain resolve
  --node <old> --action supersede --by <new>`);
- save durable knowledge after substantial work, with `--source file:` when it
  comes from a file;
- never ask the user about graft in the normal path: surface it only when it is
  broken, data loss is suspected, or an irreversible action cannot be decided
  from context.

The model decides whether to follow the instruction. Skills are useful — they shape what the agent **wants** to do; the details live in the `graft` skill's *Lifecycle* section.

For Claude Code we ship six skills:

| Skill            | Purpose |
| ---------------- | ------- |
| `graft`          | The master skill: orchestration, profile guidance, CLI reference, troubleshooting. |
| `graft-init`     | One-shot configurator: writes a `<!-- graft:start -->...<!-- graft:end -->` block into `CLAUDE.md`. |
| `recall`         | Smart search: tries `query`, falls back to `retrieve`, then to `explore`, escalating only when results are weak. |
| `memoryze`       | Distills the current conversation into 1–5 well-formed nodes and saves them. |
| `learn`          | Batch-ingestion from external sources (codebase, docs tree): plan + confirm + ingest. `/learn docs` takes in all of a repository's documentation (README, docs/, ADRs, guides), incrementally on re-runs. `/learn bootstrap` is the unattended, progressive cold start of a whole project: a topic map, bounded runs by importance (task area first), coverage tracked by `graft project`. |
| `memory-audit`   | Maintenance pass + health check: runs `graft maintain` (apply-safe, scan, resolve each candidate against the current code) and reports hit rate, hoarding ratio, reuse. |

All six ship in the graft plugin (`plugins/graft/`), installed from the marketplace
(`/plugin install graft@graft`), where they are namespaced as `/graft:<name>`. Without
the marketplace, `graft setup` copies them into `~/.claude/skills/`.

### Plugin hooks (Claude Code only)

Graft writes no harness configuration. Installing the integration copies skills;
`/graft-init` writes one rule into the instruction file the agent already reads.
Nothing else on the machine is modified, which is what makes the integration
reversible: delete the skills directory and the rule block.

The Claude Code **plugin** also carries two hooks (`plugins/graft/hooks/hooks.json`),
active only while the plugin is installed and enabled, so no `settings.json` is
edited:

| Event | Command | What it does |
| ----- | ------- | ------------ |
| `SessionStart` (startup, resume, clear) | `graft hook session-start` | Runs the `graft status` logic for the session's directory and, when housekeeping is due, injects one `graft:` line with the `next` steps. Nothing due, nothing printed. |
| `UserPromptSubmit` | `graft hook prompt` | Runs `graft query` on the prompt (first 1000 bytes; slash commands and prompts under 3 words skipped) and injects the note only on a `STRONG` hit, with its id, title and the first 800 bytes of its body. `WEAK` and `MISS` inject nothing. |

Both are the graft binary itself reading the hook JSON on stdin, so no bash or
PowerShell script has to work everywhere. Neither starts the daemon (a cold start
loads the model, which must not happen on the prompt path): until the first graft
command of the session has started it, the prompt lookup is skipped. Both print
nothing and exit 0 on any failure, and the command ends with `; exit 0`, so a
missing or older `graft` binary cannot block a prompt. Timeout: 5 s each; a
lookup takes about 0.2 s on a warm daemon.

Opt out with `GRAFT_HOOKS=0` in the environment (or in `settings.json` `env`), or
`GRAFT_HOOK_PROMPT=0` for the prompt lookup only; or disable the plugin.

`integrations/optional/hooks/` keeps the older hand-wired scripts (`PostToolUse`,
`Stop` save proposals) for people who want them; do not wire their
`UserPromptSubmit` lookup next to the plugin's, or every prompt is looked up twice.

---

## MCP server (`integrations/mcp-server/`)

For chat clients that can't run subprocesses, MCP is the bridge.

### Local stdio (development)

```bash
cd integrations/mcp-server
pip install -e .             # or: uv pip install -e .

# Start graftd locally first.
graft stats

# Configure your client to launch:
python integrations/mcp-server/server.py
```

The stdio server wraps the `graft` CLI and speaks MCP on stdin / stdout. No auth — intended for local development.

### Production HTTP gateway (`oauth_gateway.py`)

An ASGI resource server. Mounts MCP streamable HTTP at `/mcp` and proxies authenticated REST calls under `/v1/*` to the local daemon (default `http://127.0.0.1:9977`).

```bash
export GRAFT_OAUTH_ISSUER_URL="https://issuer.example.com"
export GRAFT_OAUTH_RESOURCE_SERVER_URL="https://graft.example.com/mcp"
export GRAFT_OAUTH_AUDIENCE="https://graft.example.com"
export GRAFT_OAUTH_REQUIRED_SCOPES="graft:read"
export GRAFT_UPSTREAM_HTTP="http://127.0.0.1:9977"

uvicorn oauth_gateway:app --host 127.0.0.1 --port 8080
```

Put HTTPS termination in front (Caddy, nginx, Traefik). The external OIDC provider handles login, consent, client registration, and token issuance; graft validates access tokens, audience, issuer, expiration, and scopes.

### Tools exposed via MCP

Read tools (require `graft:read` in remote mode):

`graft_query`, `graft_retrieve`, `graft_explore`, `graft_classify`, `graft_get`, `graft_stats`, `graft_analytics`.

Write tools (require `graft:write`):

`graft_insert`.

Admin tools (require `graft:admin`):

`graft_delete`, plus the profile-management tools (`profile add/remove/import/export/merge/list/current`).

### Scope policy at the REST proxy

| Scope            | REST endpoints |
| ---------------- | -------------- |
| `graft:read`     | `GET /v1/match`, `/v1/search`, `/v1/explore`, `/v1/classify`, `/v1/nodes/{id}`, `/v1/view` |
| `graft:write`    | `POST /v1/insert` |
| `graft:admin`    | `DELETE /v1/nodes/{id}` |

`GET /v1/healthz` is always unauthenticated, for container probes.

---

## Operation-name mapping

For consistency, every adapter exposes the same set of operations under the same names:

| CLI subcommand     | MCP tool name        | What it does |
| ------------------ | -------------------- | ------------ |
| `insert`           | `graft_insert`       | Save a new node (title + body + keywords + optional supersession). |
| `query`            | `graft_query`        | Cache lookup (STRONG / WEAK / MISS) with multi-signal gating. |
| `retrieve`         | `graft_retrieve`     | Hybrid top-k via RRF. |
| `explore`          | `graft_explore`      | Beam-search graph walk. |
| `get`              | `graft_get`          | Fetch a node by `id_hex`. |
| `delete`           | `graft_delete`       | Hard-delete by id (admin only on remote). |
| `classify`         | `graft_classify`     | Suggest keywords for a draft title. |
| `stats`            | `graft_stats`        | Counts + similarity percentiles. |
| `analytics`        | `graft_analytics`    | Streams the local usage log. |
| `consolidate`      | _(not exposed)_      | CLI-only; admin pass. |

---

## Guidance for an LLM author

If you're writing your own skill / `AGENTS.md`, the rule of thumb is:

1. **Search before writing.** Always call `query` (or `retrieve`) **before** `insert`. If STRONG hit → reuse; if MISS → consider inserting.
2. **`query` vs `retrieve`.** `query` returns one verified result. `retrieve` returns up to N candidates. Use `query` when you want a confidence-gated answer; `retrieve` when you want a list to choose from.
3. **`explore` for related problems.** "What do I know about X?" or "What's connected to this decision?".
4. **`classify` before `insert`** if the user did not pass explicit keywords.

---

## Per-adapter notes

### Claude Code

The plugin (`/plugin install graft@graft`) or `graft setup` provides the skills, then `/graft-init` installs the CLI if needed and writes the rule into `CLAUDE.md` plus `.claude/rules/graft.md`. The plugin adds the two hooks above; `graft setup` does not. `~/.claude/settings.json` is never touched. See [`../../integrations/claude-code/README.md`](../../integrations/claude-code/README.md) for recommended `permissions.allow` entries.

### Codex

The plugin (`codex plugin add graft@graft`) or `graft setup` provides the skills, then `graft-init` installs the CLI if needed and writes the zero-touch rule into `AGENTS.md`; the agent drives the lifecycle from `graft status`. No hooks ship for Codex: `~/.codex/hooks.json` and `~/.codex/config.toml` are never touched.

### Claude Desktop / ChatGPT

Configure the MCP server in the client's connector JSON. Examples are shipped:

- `integrations/claude-ai/claude_desktop_config.json`
- `integrations/chatgpt/mcp_config.json`

Both wire the stdio MCP server (`integrations/mcp-server/server.py`) so the chat client can call the graft tools.

### Gemini CLI

`GEMINI.md` is shipped with the same "search before / save after" instructions as the other CLI assistants.

### Open Code

`graft setup` copies native skills into `~/.config/opencode/skills/`, then `/graft-init` writes the rule into `AGENTS.md`. Agent settings are never touched.

---

## What's missing and how to improve it

- **JetBrains / VS Code extensions.** The CLI works fine when invoked from a build task, but a real extension that surfaces `graft query` on hover or `graft retrieve` from a code-action context would be a major UX win.
- **Aider / Continue / Cursor integrations.** Each has its own custom-tool surface; the graft CLI is small enough to wrap in any of them in under 100 lines, but the wrappers are not in this repo yet.
- **A common "agent integration test" target** that drives `query → insert → query` end-to-end and checks the STRONG-hit cycle. Today the integrations are tested manually.
- **Capability auto-detection on first run.** When an integration starts, it could call `graft stats` to check the daemon's health and `graft profile current` to print the active profile. Today the user has to know to do that.
- **A non-MCP HTTP path** for chat clients without MCP. The OAuth gateway is the obvious place, but exposing `graft_*` tools as plain HTTP endpoints (a custom GPT action, say) would broaden reach.
- **Multi-language SDK shims.** The CLI is the universal contract, but a thin TypeScript / Python wrapper would make web integrations cleaner.
