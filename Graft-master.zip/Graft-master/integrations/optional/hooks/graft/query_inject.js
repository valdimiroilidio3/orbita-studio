#!/usr/bin/env node
/*
 * UserPromptSubmit hook for graft (Claude Code + Codex).
 *
 * Reads { session_id, prompt, ... } from stdin, runs `graft query <prompt>`,
 * and emits a compact context block on stdout — both Claude Code and Codex
 * inject UserPromptSubmit stdout into the agent's prompt for the upcoming turn.
 *
 * Also surfaces any /memoryze proposal queued by the Stop hook on the previous
 * turn (the agent sees it before the user's actual prompt).
 *
 * Failures are silent (exit 0). Latency cap via 5s timeout on the CLI call.
 */

const { execFileSync } = require('child_process');
const { readFileSync, unlinkSync, mkdirSync, renameSync } = require('fs');
const path = require('path');
const os = require('os');

function inferStateDir() {
  if (process.env.GRAFT_HOOK_STATE_DIR) return process.env.GRAFT_HOOK_STATE_DIR;
  const scriptPath = __filename.toLowerCase();
  const agentDir = scriptPath.includes(`${path.sep}.codex${path.sep}`) ? '.codex' : '.claude';
  return path.join(os.homedir(), agentDir, 'hooks', 'graft', 'state');
}

const STATE_DIR = inferStateDir();
const MIN_WORDS_FOR_QUERY = 4;
// Windows CreateProcess imposes a ~8KB cap on the full command line and the
// active codepage (e.g. CP1252) mangles non-ASCII in argv. Cap the prompt to
// 4000 chars before passing it to `graft query` as an argv element.
const MAX_QUERY_PROMPT_CHARS = 4000;
const WEAK_EXPLORE_DEPTH = positiveInt(process.env.GRAFT_HOOK_WEAK_EXPLORE_DEPTH, 3);
const WEAK_EXPLORE_BEAM = positiveInt(process.env.GRAFT_HOOK_WEAK_EXPLORE_BEAM, 4);

// Restrict the hook state dir to the current user (no-op on Windows, but
// harmless). State files containing session ids and per-turn file paths
// should not be readable by other local accounts.
function safeMkdir(d) { try { mkdirSync(d, { recursive: true, mode: 0o700 }); } catch (_) {} }
function readStdinSync() { try { return readFileSync(0, 'utf8'); } catch (_) { return ''; } }
// Reject session ids that aren't safe to interpolate into a filename. We
// only accept [A-Za-z0-9_-]{1,128}; anything else (path separators, dots,
// non-ASCII, suspiciously long) silently disables the cache for this turn.
function safeSessionId(s) {
  return typeof s === 'string' && /^[A-Za-z0-9_-]{1,128}$/.test(s) ? s : null;
}
function positiveInt(raw, fallback) {
  const n = Number.parseInt(raw, 10);
  return Number.isFinite(n) && n > 0 ? n : fallback;
}

function runGraft(args) {
  try {
    return execFileSync('graft', args, {
      encoding: 'utf8',
      timeout: 5000,
      stdio: ['ignore', 'pipe', 'ignore'],
    });
  } catch (_) {
    return null;
  }
}

function parseGraft(args) {
  const out = runGraft(args);
  if (!out) return null;
  try { return JSON.parse(out); } catch (_) { return null; }
}

function classifyKeywords(title) {
  if (!title) return [];
  const resp = parseGraft(['classify', '--title', title]);
  const kws = resp && resp.result && resp.result.suggested_keywords;
  return Array.isArray(kws)
    ? kws.filter(k => typeof k === 'string' && k.trim()).slice(0, 5)
    : [];
}

function exploreWeak(title, keywords) {
  if (!title || !keywords.length) return [];
  const args = ['explore', title];
  for (const kw of keywords) args.push('--keyword', kw);
  args.push('--depth', String(WEAK_EXPLORE_DEPTH), '--beam', String(WEAK_EXPLORE_BEAM));
  const resp = parseGraft(args);
  const nodes = resp && resp.result && resp.result.nodes;
  return Array.isArray(nodes) ? nodes.filter(n => n && n.title).slice(0, 8) : [];
}

function exploreStrong(idHex, title) {
  if (!idHex || !title) return [];
  const node = parseGraft(['get', idHex]);
  const keywords = node && node.result && Array.isArray(node.result.keywords)
    ? node.result.keywords.filter(k => typeof k === 'string' && k.trim()).slice(0, 5)
    : [];
  if (!keywords.length) return [];
  const args = ['explore', title];
  for (const kw of keywords) args.push('--keyword', kw);
  args.push('--depth', String(WEAK_EXPLORE_DEPTH), '--beam', String(WEAK_EXPLORE_BEAM));
  const resp = parseGraft(args);
  const nodes = resp && resp.result && resp.result.nodes;
  if (!Array.isArray(nodes)) return [];
  return nodes
    .filter(n => n && n.title && n.id_hex !== idHex && (n.depth_reached || 0) >= 1)
    .slice(0, 6);
}

(function main() {
  safeMkdir(STATE_DIR);

  const raw = readStdinSync().replace(/^﻿/, '');
  if (!raw) return;

  let payload;
  try { payload = JSON.parse(raw); } catch (_) { return; }

  const prompt = (payload && typeof payload.prompt === 'string') ? payload.prompt.trim() : '';
  const rawSessionId = (payload && typeof payload.session_id === 'string') ? payload.session_id : '';
  const sessionId = safeSessionId(rawSessionId);

  // (1) Surface any pending /memoryze proposal from prior turn's Stop hook.
  // Atomic consume: rename-then-read so that if two UserPromptSubmit hooks
  // race (or the user double-submits), only the winner sees the proposal —
  // the loser hits ENOENT and exits silently, avoiding double injection.
  if (sessionId) {
    const proposalFile = path.join(STATE_DIR, `${sessionId}.proposal`);
    const claimed = `${proposalFile}.consumed.${process.pid}`;
    let renamed = false;
    try {
      renameSync(proposalFile, claimed);
      renamed = true;
    } catch (_) { /* ENOENT — another instance won, or no proposal */ }
    if (renamed) {
      try {
        const proposal = readFileSync(claimed, 'utf8').trim();
        if (proposal) {
          process.stdout.write('<graft-proposal>\n');
          process.stdout.write(proposal + '\n');
          process.stdout.write('</graft-proposal>\n\n');
        }
      } catch (_) {}
      try { unlinkSync(claimed); } catch (_) {}
    }
  }

  // (2) Skip query for trivial / acknowledgement-only prompts.
  if (!prompt || prompt.split(/\s+/).filter(Boolean).length < MIN_WORDS_FOR_QUERY) return;

  // (3) Run graft query.
  const queryPrompt = prompt.length > MAX_QUERY_PROMPT_CHARS
    ? prompt.slice(0, MAX_QUERY_PROMPT_CHARS)
    : prompt;
  const resp = parseGraft(['query', queryPrompt]);
  const r = resp && resp.result;
  if (!r || !r.hit) return;

  if (r.hit === 'STRONG') {
    process.stdout.write('<graft-cache hit="STRONG">\n');
    if (r.id_hex) process.stdout.write(`id_hex: ${r.id_hex}\n`);
    if (r.title) process.stdout.write(`title: ${r.title}\n`);
    if (r.body) process.stdout.write(`body: ${r.body}\n`);
    // The region around a STRONG hit is where the adjacent trap or the
    // constraining decision lives. Walk it here so the agent gets the
    // neighbourhood for free instead of having to remember to explore.
    const neighbours = exploreStrong(r.id_hex, r.title);
    if (neighbours.length) {
      process.stdout.write('region (depth >= 1, open with graft get <id_hex> what may contradict or constrain the answer):\n');
      for (const n of neighbours) {
        process.stdout.write(`- [d${n.depth_reached}] ${n.title} id_hex=${n.id_hex}\n`);
      }
    }
    process.stdout.write('</graft-cache>\n');
    return;
  }

  if (r.hit === 'WEAK') {
    const title = r.title || prompt;
    const keywords = classifyKeywords(title);
    const candidates = exploreWeak(title, keywords);

    process.stdout.write('<graft-cache hit="WEAK">\n');
    if (r.id_hex) process.stdout.write(`weak_id_hex: ${r.id_hex}\n`);
    if (r.title) process.stdout.write(`weak_title: ${r.title}\n`);
    if (keywords.length) process.stdout.write(`classified_keywords: ${keywords.join(', ')}\n`);
    process.stdout.write(`explore_depth: ${WEAK_EXPLORE_DEPTH}\n`);
    process.stdout.write(`explore_beam: ${WEAK_EXPLORE_BEAM}\n`);
    if (candidates.length) {
      process.stdout.write('explore_candidates:\n');
      for (const n of candidates) {
        const score = typeof n.score === 'number' ? ` score=${n.score.toFixed(3)}` : '';
        const id = n.id_hex ? ` id_hex=${n.id_hex}` : '';
        process.stdout.write(`- ${n.title}${id}${score}\n`);
      }
    }
    process.stdout.write('If you use this WEAK match as the basis for a different solution, save a new node that strengthens the memory.\n');
    process.stdout.write('</graft-cache>\n');
    return;
  }

  if (r.hit === 'MISS') {
    // Deliberately do NOT inject fallback_retrieve neighbors. The verify
    // pipeline declared the top-1 sub-threshold; surfacing those nodes would
    // contradict the system's own gating and feed retrieval-augmented
    // hallucination. Empirical: on a query whose answer was actually saved
    // in the graph, the top-5 fallback contained 1 tangentially relevant +
    // 4 unrelated nodes — 80% noise. The agent can call /recall explicitly
    // when it wants browsing.
    process.stdout.write('<graft-cache hit="MISS" queried="true"/>\n');
  }
})();
