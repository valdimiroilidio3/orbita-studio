# Optional — graft harness hooks

> **Not installed by `graft setup`.** The supported integration copies skills and
> writes one rule into your instruction file; nothing else on the machine is
> touched. These hooks are the opt-in layer for people who want the harness to
> guarantee the lookup instead of trusting the agent to remember it. Wiring them
> means editing your own `settings.json` by hand, and it is on you to keep that
> edit reversible.
>
> **Using the Claude Code plugin?** It already ships a prompt lookup and a
> session hint (`plugins/graft/hooks/hooks.json`, see
> [`docs/integrations/`](../../../docs/integrations/README.md#plugin-hooks-claude-code-only)).
> With both wired, every prompt is looked up twice: set `GRAFT_HOOK_PROMPT=0` to
> keep only these, or skip `query_inject.js` to keep only the plugin's.

Three event hooks that move graft from "the agent should remember to use it" to "the harness guarantees it":

| Event              | Script                  | What it does                                                                                              |
| ------------------ | ----------------------- | --------------------------------------------------------------------------------------------------------- |
| `UserPromptSubmit` | `query_inject.js`       | Runs `graft query <prompt>`. STRONG injects `id_hex`, title, body, and the surrounding region (`explore --depth 3 --beam 4` from the hit), because the node one hop away is usually the gotcha the hit itself does not mention. WEAK classifies the weak title, runs `explore --depth 3 --beam 4` by default, and injects candidate titles. MISS injects only `<graft-cache hit="MISS" queried="true"/>`. Also surfaces any `<graft-proposal>` queued by the previous turn's Stop hook. |
| `PostToolUse` (matcher `Edit\|Write\|MultiEdit\|NotebookEdit`) | `mark_candidate.js`     | Records the tool call + file path in `~/.claude/hooks/graft/state/<session>.candidates`, then emits a same-turn `<graft-proposal timing="post-tool">` so the agent can save before its final response. |
| `Stop`             | `propose_memoryze.js`   | If the session accumulated candidates, writes a fallback `/memoryze` proposal to `<session>.proposal`. The next `UserPromptSubmit` surfaces it for clients that do not surface PostToolUse stdout. |

The scripts are pure Node, no external deps, BOM-tolerant, all silent on error (exit 0 always). Latency cap via per-hook timeouts.

## Install

```bash
# 1. Copy scripts to user-level hooks dir.
mkdir -p ~/.claude/hooks/graft
cp integrations/optional/hooks/graft/*.js ~/.claude/hooks/graft/

# 2. Wire the hooks into ~/.claude/settings.json (merge with any existing
#    hooks). Example block:
```

```json
{
  "hooks": {
    "UserPromptSubmit": [
      {
        "hooks": [
          { "type": "command", "command": "node", "args": ["$HOME/.claude/hooks/graft/query_inject.js"], "timeout": 10 }
        ]
      }
    ],
    "PostToolUse": [
      {
        "matcher": "Edit|Write|MultiEdit|NotebookEdit",
        "hooks": [
          { "type": "command", "command": "node", "args": ["$HOME/.claude/hooks/graft/mark_candidate.js"], "timeout": 5 }
        ]
      }
    ],
    "Stop": [
      {
        "hooks": [
          { "type": "command", "command": "node", "args": ["$HOME/.claude/hooks/graft/propose_memoryze.js"], "timeout": 5 }
        ]
      }
    ]
  }
}
```

On Windows, replace `$HOME` with the absolute path: `C:/Users/<you>/.claude/hooks/graft/...`. The hooks need `node` and `graft` in the PATH visible to Claude Code at session start.

## MISS policy

On a cache MISS, the hook **does not inject the `fallback_retrieve` neighbors**. The verify pipeline already declared the top-1 sub-threshold; surfacing those nodes would contradict the system's own gating and feed retrieval-augmented hallucination. Empirically: on a query whose answer was actually saved in the graph, the top-5 fallback contained 1 tangentially relevant + 4 unrelated nodes (80% noise). The agent calls `/recall` explicitly when it wants browsing.

The injected MISS block is `<graft-cache hit="MISS" queried="true"/>`, which
also means the query already ran for the current user prompt. The agent should
not immediately repeat `graft query`; it should only escalate with
`graft retrieve` or `graft explore` when broader context is worth the extra
call.

## Save policy

The hook layer does not call `graft insert` directly. It surfaces a same-turn
proposal after edits, and the agent decides automatically before its final
response whether the work is worth memory. If yes, it saves with `/memoryze`
when available, otherwise a Markdown body plus `graft classify --title "<title>"`
followed by `graft insert` with 2-5 good keywords. The Stop hook keeps a
next-turn fallback for clients that do not expose PostToolUse stdout.

## Skip rules

- Prompts shorter than 4 words skip the query (avoids noise on "ok thanks" turns).
- All hooks exit 0 on any error — they never block the user's prompt.

## State files

`~/.claude/hooks/graft/state/` accumulates per-session `<session>.candidates` (JSONL) and `<session>.proposal` (text). The proposal is consumed and deleted on the next `UserPromptSubmit`. The candidates file is consumed and deleted by `Stop`. Stale files from crashed sessions are harmless but you can clean them periodically.
